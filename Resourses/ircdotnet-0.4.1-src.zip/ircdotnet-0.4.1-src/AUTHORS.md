*IRC.NET* is copyright � Alex Regueiro 2011.  
*IRC.NET* sample projects are copyright � Alex Regueiro 2011.  

All included software is licensed under the MIT License, available in full in
the ``LICENSE`` file.

The following persons and groups are acknowledged for their contributions to
specific releases of the software.

Version 0.4.1
-------------

Alex Regueiro <alexreg@gmail.com>
> Project Lead, Programming

Claus J�rgensen <10229@iha.dk>
> Programming (WP7 port)

Evan Plumlee <eplumlee@yahoo.com>
> Testing

Version 0.4.0
-------------

Alex Regueiro <alexreg@gmail.com>
> Project Lead, Programming

Version 0.3.x
-------------

Alex Regueiro <alexreg@gmail.com>
> Project Lead, Programming

Version 0.2.x
-------------

Alex Regueiro <alexreg@gmail.com>
> Project Lead, Programming

Version 0.1.x
-------------

Alex Regueiro <alexreg@gmail.com>
> Project Lead, Programming
